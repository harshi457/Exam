#pragma once
#include book.h
#include AudioBook.h

Book *book;

AudioBook::void AudioBook(string title,string authorName,string voiceActor):Book(title,authorName){
    this->voiceActor = voiceActor;
}

AudioBook:: void setVoiceActor(string voiceActor){
    this->voiceActor=voiceActor;
}

AudioBook:: string getVoiceActor(){
    return this->voiceActor;
}

Book::void printDescription(){
    string tempBook;
    tempBook = &book;
    

}


