#include libraries.h

public:
    string title;
    string authorName;
    void Book(string title, string authorName);
    void setTitle(string title);
    string getTitle();
    void setTitle(string authorName);
    string getAuthorName();
    void printDescription();