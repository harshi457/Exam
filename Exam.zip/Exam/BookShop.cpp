#include BookShop.h

define SizeArray 5;

Book* list2=static_cast<Book*>(malloc(SizeArray*sizeof(Book)));
int a=50;
cout<<&a<<endl;
for(int i=0;i<SizeArray;i++){
         new(&list2[i])Book();
         cout<<"Enter the Title Name"<<endl;
                
}
    



    
    
