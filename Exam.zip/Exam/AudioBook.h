#include libraries.h

public:
    string voiceActor;
    void AudioBook(string title,string authorName,string voiceActor);
    void setVoiceActor(string voiceActor);
    string getVoiceActor();
    void printDescription();
    