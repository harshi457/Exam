#pragma once
#include book.h


Book::void Book(string title, string authorName){
    this->title = title;
    this->authorName= authorName;
}

Book::void setTitle(string title){
    this->title = title;
}

Book:: string getTitle(){
    return this->title;
}

Book::void setTitle(string authorName){
    this->authorName = authorName;
}

Book:: string getAuthorName(){
    return this->authorName;
}

Book::void printDescription(){
    cout<<"Details of Book"<<endl;
    cout<<"Title of the Book : "<< getTitle() << endl;
    cout<<"Author of the Book : " << getAuthorName() << endl;
}

